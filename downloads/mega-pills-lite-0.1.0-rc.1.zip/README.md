# Mega Pills Lite

Version 0.1.0-rc.1 is a standalone, documentation-only workflow. It contains one skill and no scripts, connections, accounts, configuration changes, or runtime dependencies.

Read `skills/mega-pills-lite/SKILL.md` directly, or use the folder with a compatible Agent Skills host. The archive also includes a portable plugin manifest for compatible hosts. The archive is not an installer. Host loading, settings, tools, and permissions are separate.

Try: “Turn these mixed project notes into a draft update, and tell me what I would still have to verify before sending.”

Release candidate: not a license grant or publication notice. A distributor should confirm rights and provide explicit licensing terms before releasing it publicly.
